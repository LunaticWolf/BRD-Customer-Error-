package Insert;

//import java.io.BufferedWriter;
import java.io.FileWriter;
//import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.TreeSet;

import Connection.ConnectionI;
import Connection.OracleConnection;
import Main.Customer;
import Validation.Rejection;

public class InsertToDb implements InsertDao {
	Customer customer;
	Connection conn = null;
	ConnectionI c = null;
	PreparedStatement ps = null;
	int rowsAffected = 0;

	public Connection connection() {
		c = new OracleConnection();
		conn = c.myConnection();
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public void conditionCheck(String server, String str, String rejection, Customer customer,FileWriter bw) {
		if (rejection.equalsIgnoreCase("r")) {
			Rejection r = new Rejection();

			try {
				r.recordLevel(server, str, customer,bw);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {

			Rejection r = new Rejection();
			r.fileLevel(server, str, customer,bw);
		}
	}
	
	public TreeSet<String> fetch_customer_code()
	{
		TreeSet<String> hs=new TreeSet<String>();
		
		try 
		{
			Connection conn=connection();
			Statement stmt=null;
			ResultSet rs=null;
			stmt=conn.createStatement();
			rs=stmt.executeQuery("select customer_code from TABLE67");
			
			while(rs.next())
			{
				String code=rs.getString(1);
				
				hs.add(code);
			}
		
	}
		catch(Exception e)
		{}
		return hs;
	}

	public int inputbd(String server, Customer customer, Connection conn) {
		try {

			ps = conn.prepareStatement("insert into TABLE67 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			ps.setInt(1, customer.getCustomer_id());
			ps.setString(2, customer.getCustomer_code());
			ps.setString(3, customer.getCustomer_name());
			ps.setString(4, customer.getCustomer_address1());
			ps.setString(5, customer.getCustomer_address2());
			ps.setInt(6, customer.getCustomer_pinCode());
			ps.setString(7, customer.getEmail_address());
			ps.setString(8, customer.getContact_number());
			ps.setString(9, customer.getPrimaryConatctPerson());
			ps.setString(10, customer.getRecord_status());
			ps.setString(11, customer.getActive_inactiveFlag());
			ps.setString(12, customer.getCreate_date());
			ps.setString(13, customer.getCreated_by());
			ps.setString(14, customer.getModified_date());
			ps.setString(15, customer.getModified_by());
			ps.setString(16, customer.getAuthorized_date());
			ps.setString(17, customer.getAuthorized_by());

			rowsAffected = ps.executeUpdate();
			
		} catch (SQLException e) {
			System.err.println("ERROR OCCURED");
		}
		return rowsAffected;
	}

}
