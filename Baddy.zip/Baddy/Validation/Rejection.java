package Validation;

//import java.io.BufferedWriter;
import java.io.FileWriter;
//import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.TreeSet;

import Insert.InsertDao;
import Insert.InsertToDb;
import Main.Customer;
import Main.MainClass;

public class Rejection {

	ValidationI vm = new ValidateMethods();

	public void recordLevel(String server, String str, Customer customer,
			FileWriter bw) throws IOException {

		InsertDao dao = new InsertToDb();
		TreeSet<String> set = dao.fetch_customer_code();

		boolean code = vm.validCustomerCode(customer, set);
		set.add(customer.getCustomer_code());

		boolean name = vm.validCustomerName(customer);

		boolean pinCode = vm.validPinCode(customer);

		boolean record = vm.validRecordStatus(customer);

		boolean flag = vm.validFlag(customer);

		boolean email = vm.validEmail(customer);

		Connection conn = dao.connection();
		if (code && name && record && pinCode && flag && email) {
			int rowsAffected = dao.inputbd(server, customer, conn);

			if (rowsAffected > 0)
				System.out.println("Successfully executed..");

			else
				System.err.println("ERROR.");

			try {
				conn.commit();
				conn.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		} else {

			try {
				String newLine = System.getProperty("line.separator");
				bw.append(newLine+customer.getCustomer_code()+"~"+customer.getCustomer_name()+"~"+customer.getCustomer_address1()+"~"
				+customer.getCustomer_address2()+"~"+customer.getCustomer_pinCode()+"~"+customer.getEmail_address()+"~"
				+customer.getContact_number()+"~"+customer.getPrimaryConatctPerson()+"~"+customer.getRecord_status()
				+"~"+customer.getActive_inactiveFlag()+"~"+customer.getCreated_by()+"~"+customer.getCreate_date()
				+"~"+customer.getAuthorized_by()+"~"+customer.getAuthorized_date()+"~"+customer.getModified_by()
				+"~"+customer.getModified_date()+newLine);
//				System.err.println("Already exist!! ");
				if (code == false) {
					
					//System.out.println("not working here !");
					bw.append("Error in code"+newLine);
					bw.write("\n");
					bw.append("Code Error");
					bw.write("\n");
					bw.flush();
				} else if (name == false) {
					bw.append("Error in code"+newLine);
					bw.write("\n");
					System.out.println("\n");
					bw.append("Code Error");
					bw.write("\n");
					bw.flush();
				} else if (pinCode == false) {
					bw.append("Error in code"+newLine);
					bw.write("\n");
					bw.append("Error in pincode");
					bw.write("\n");
					bw.flush();
				} else if (record == false) {
					bw.append("Error in code"+newLine);
					bw.write("\n");
					bw.append("Error in record");
					bw.write("\n");
					bw.flush();
				} else if (flag == false) {
					bw.append("Error in code"+newLine);
					bw.write("\n");
					bw.append("Error in flag value");
					bw.write("\n");
					bw.flush();
				} else if (email == false) {
					bw.append("Error in code"+newLine);
					bw.write("\n");
					bw.append("Error in email format");
					bw.write("\n");
					bw.flush();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	public void fileLevel(String server, String str, Customer customer,
			FileWriter bw) {
		InsertDao dao = new InsertToDb();
		TreeSet<String> set = dao.fetch_customer_code();

		int c = 0;

		boolean code = vm.validCustomerCode(customer, set);
		set.add(customer.getCustomer_code());

		boolean name = vm.validCustomerName(customer);

		boolean pinCode = vm.validPinCode(customer);

		boolean record = vm.validRecordStatus(customer);

		boolean flag = vm.validFlag(customer);

		boolean email = vm.validEmail(customer);

		Connection conn = dao.connection();

		if (code && name && record && pinCode && flag && email) {
			int rowsAffected = dao.inputbd(server, customer, conn);
			c = c + 1;

			if (rowsAffected > 0)
				System.out.println("done");
			else
				System.out.println("Some error");
		} else {
			try {
				String newLine = System.getProperty("line.separator");
				bw.append(newLine+customer.getCustomer_code()+"~"+customer.getCustomer_name()+"~"+customer.getCustomer_address1()+"~"
						+customer.getCustomer_address2()+"~"+customer.getCustomer_pinCode()+"~"+customer.getEmail_address()+"~"
						+customer.getContact_number()+"~"+customer.getPrimaryConatctPerson()+"~"+customer.getRecord_status()
						+"~"+customer.getActive_inactiveFlag()+"~"+customer.getCreated_by()+"~"+customer.getCreate_date()
						+"~"+customer.getAuthorized_by()+"~"+customer.getAuthorized_date()+"~"+customer.getModified_by()
						+"~"+customer.getModified_date()+newLine);
				
				if (code == false) {
					bw.append("Error in code"+newLine);
					bw.write("\n");
					/*bw.append("Error in code");
					bw.write("\n");*/
					bw.flush();
				} else if (name == false) {
					bw.append("Error in code"+newLine);
					/*bw.write("\n");
					bw.append("Error in name");
					bw.write("\n");*/
					bw.flush();
				} else if (pinCode == false) {
					bw.append("Error in code"+newLine);
					/*bw.write("\n");
					bw.append("Error in pincode");
					bw.write("\n");*/
					bw.flush();
				} else if (record == false) {
					bw.append("Error in code"+newLine);
					/*bw.write("\n");
					bw.append("Error in record");
					bw.write("\n");*/
					bw.flush();
				} else if (flag == false) {
					bw.append("Error in code"+newLine);
					/*bw.write("\n");
					bw.append("Error in flag value");
					bw.write("\n");*/
					bw.flush();
				} else if (email == false) {
					bw.append("Error in code"+newLine);
					/*bw.write("\n");
					bw.append("Error in email format");
					bw.write("\n");*/
					bw.flush();
				}
				conn.rollback();

			} catch (Exception e) {
				e.printStackTrace();
			}
			if (MainClass.noOfrows == c) {
				try {
					conn.commit();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
	}
}
