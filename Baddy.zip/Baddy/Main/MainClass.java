package Main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
//import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

import Insert.InsertDao;
import Insert.InsertToDb;

public class MainClass {
	public static int noOfrows=0;
	static Customer customer = new Customer();
	static BufferedReader br;
	

	public static void main(String[] args) {
		
		int count = 1;
		String str;

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Whrich type of database you want to work with\n\n"
				+ "1. Oracle\n" + "2. MySql\n" + "3. Sqlserver");
		String server = sc.next();
		System.out.println("Enter the location");
		String location = sc.next();
		System.out.println("Enter the file name");
		String fileName = sc.next();
		System.out.println("Enter the file extention");
		String fileExtention = sc.next();

		
		while (!(fileExtention.equals("txt"))) {
			System.out.println("Enter valid file extention");
			fileExtention = sc.next();
		}

		System.out.println("Enter rejection level");
		String rejection = sc.next();

		try {
			
			FileReader fr = new FileReader(location + ":/" + fileName + "."
					+ fileExtention);
			 br = new BufferedReader(fr);
			 
			 //BufferedWriter bw = null;
				FileWriter bw = new FileWriter("C:\\Users\\nsbt.trainee\\Desktop\\ErrorFile.txt", true);
				//bw = new BufferedWriter(fw);
				
			InsertDao dao = new InsertToDb();

			while ((str = br.readLine()) != null) {
				String st[] = new String[20];
				st = str.split("~", -1);
				
				noOfrows=noOfrows+1;
				try {
					customer.setCustomer_id(count);
					count = count + 1;
					customer.setCustomer_code(st[0]);
					customer.setCustomer_name(st[1]);
					customer.setCustomer_address1(st[2]);
					customer.setCustomer_address2(st[3]);
					customer.setCustomer_pinCode(Integer.parseInt(st[4]));
					customer.setEmail_address(st[5]);
					customer.setContact_number(st[6]);
					customer.setPrimaryConatctPerson(st[7]);
					customer.setRecord_status(st[8]);
					customer.setActive_inactiveFlag(st[9]);
					customer.setCreate_date(st[10]);
					customer.setCreated_by(st[11]);
					customer.setModified_date(st[12]);
					customer.setModified_by(st[13]);
					customer.setAuthorized_date(st[14]);
					customer.setAuthorized_by(st[15]);
				}

				catch (ArrayIndexOutOfBoundsException e)
				{}

				finally {

					dao.conditionCheck(server, str, rejection, customer,bw);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("File not found");
		}

		sc.close();
	}
}
