package Connection;



public class ConnectionFactory
{
	public static ConnectionI factoryIntial(String name)
	{
		if(name.equalsIgnoreCase("ORACLE"))
		{
			return new OracleConnection();
		}
		else if(name.equalsIgnoreCase("MYSQL"))
		{
			return new MySQL();
		}
		else if(name.equalsIgnoreCase("SQLSERVER"))
		{
			return new SqlServer();
		}
		else {
			System.err.println("WRONG INPUT!! ");
			return  null;
	}
	}
}
