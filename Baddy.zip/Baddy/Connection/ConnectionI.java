package Connection;

import java.sql.Connection;

public interface ConnectionI 
{

	public Connection myConnection();
	
}
