package Connection;

import java.sql.Connection;


public class SqlServer implements ConnectionI{

	@Override
	public Connection myConnection() {
		return null;
	}

}
