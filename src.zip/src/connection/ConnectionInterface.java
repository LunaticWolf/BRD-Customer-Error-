package connection;

import java.sql.Connection;

//Connection Interface With JDBC
public interface ConnectionInterface
{

	public Connection myConnection();
	
}
